const getters = {
  getHeart (state) {
    return state.heart
  },
  getBlood (state) {
    return state.blood
  }
}

export default getters
