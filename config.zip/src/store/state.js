const state = {
  heart: [],
  blood: []
}
export default state
