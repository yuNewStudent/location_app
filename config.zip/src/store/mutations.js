const mutations = {
  setHeart (state, hertInfo) {
    state.heart = hertInfo
  },
  setBlood (state, bloodInfo) {
    state.blood = bloodInfo
  }
}

export default mutations
